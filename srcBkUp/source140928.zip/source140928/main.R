# ==========================================================================
# This program is developed to diagnosis skin status of human face.
#                                       Created by Ph.D./Prof. Jaeho H. BAE
#                           Dept. of Industrial Management, Osan University
#                                                                Sep., 2014.
#                                                     knowhow.bae@gmail.com
# ==========================================================================


main <- function(..., area="T", save="N") {
  source("coreFunctions.r")
  
  lib.call()
  
  timeTag  <- format(Sys.time(), "%Y%m%d-%H%M%S")
  
  # Step 01. Load Image and Coordination Files.
  dataFile <- list(imgFile = "", locFile = "")

  dataFile <- getFileName(dataFile)
    if(is.null(dataFile)==TRUE) on.exit()  # If working directory is not correct, this function will be terminated.

  imgData = readImage(dataFile$imgFile)
    tmplocData <- read.table(dataFile$locFile, header = FALSE, sep = ",")
    veclocData <- as.numeric(as.vector(tmplocData[1:length(tmplocData[,1])-1,1]))
  locData <- matrix(veclocData, ncol=2)

  # Step 02. Display an original Image
  keyValue <- readline("Press any key to show a loaded image.")

  display(imgData, method = "raster")

  filter = matrix(1, nc=3, nr=3)
  filter[2, 2] = -8
  imgDataEdge <- filter2(imgData, filter)
  keyValue <- readline("Press any key to show an Edge-detected image.")
  display(imgDataEdge, method="raster")
  
  
  
  x <- imgData
  for (i in 1:length(locData[,1])) {
    x <- drawCircle(x, locData[i,1], locData[i,2], 5, col="red", fill=TRUE)
  }
    
  # Step 03. Display and save a modified Image with coordination points
  keyValue <- readline("Press any key to show a checked image.")
  display(x, method = "raster")
  if (save=="Y") {writeImage(x, paste("./srcImage/AnalyzedImage01-", timeTag, ".png", sep=""), quality=100)}
  
  # Step 04. Select an area to analyze
  if (area == "L") {
    startX <- locData[9,1]
    startY <- locData[14,2]
    endX   <- locData[23,1]
    endY   <- locData[23,2]
  } else if (area == "R") {
    startX <- locData[20,1]
    startY <- locData[16,2]
    endX   <- locData[10,1]
    endY   <- locData[20,2]
  } else {
    startX <- min(locData[1:18,1])
    startY <- max(locData[1:18,2])
    endX <- max(locData[1:18,1])
    endY <- min(locData[19:length(locData[,1]),2])
  }
  
  x1 <- imgData[startX:endX, startY:endY,]
  keyValue <- readline("Press any key to show an image of selected area.")
  display(x1, method="raster")
  if (save=="Y") {writeImage(x1, paste("./srcImage/AnalyzedImage02-", timeTag, ".png", sep=""), quality=100)}
  
  # Step 05. Seperate each channel with RGB value
  x1 <- channel(x1, 'rgb')
  #x1_r <- rgbImage(red=x1[,,1])
  #x1_g <- rgbImage(green=x1[,,2])
  #x1_b <- rgbImage(blue=x1[,,3])
  #x1_t <- combine(x1_r, x1_g, x1_b, all=TRUE)
  x1_r  <- channel(x1, 'asred')
  x1_g  <- channel(x1, 'asgreen')
  x1_b  <- channel(x1, 'asblue')

  
  x1_t <- EBImage::combine(rgbImage(red=x1[,,1]), rgbImage(green=x1[,,2]), rgbImage(blue=x1[,,3]), x1)
  keyValue <- readline("Press any key to show images of RGB and original loaded.")
  display(x1_t, method="raster", all=TRUE)
  if (save=="Y") {writeImage(x1_t, paste("./srcImage/AnalyzedImage03-", timeTag, ".png", sep=""), quality=100)}

  keyValue <- readline("Press any key to show histogram of loaded image.")
  hist(x1_t)

  
  
# Segmentation and displaying
  x1_ct_r <- x1[,,1]>mean(x1[,,1]) + sd(x1[,,1])
  keyValue <- readline("Press any key to show extra-high R-value.")
  display(x1_ct_r, method="raster")
  keyValue <- readline("Press any key to show extra-high R-value in red color.")  
  display(rgbImage(red=x1_ct_r), method="raster")

  x1_ct_g <- x1[,,2]>mean(x1[,,2]) + sd(x1[,,2])
  keyValue <- readline("Press any key to show extra-high G-value.")
  display(x1_ct_g, method="raster")
  keyValue <- readline("Press any key to show extra-high G-value in green color.")
  display(rgbImage(green=x1_ct_g), method="raster")

  x1_ct_b <- x1[,,3]>mean(x1[,,3]) + sd(x1[,,3])
  keyValue <- readline("Press any key to show extra-high B-value.")  
  display(x1_ct_b, method="raster")  
  keyValue <- readline("Press any key to show extra-high B-value in blue color.")  
  display(rgbImage(blue=x1_ct_b), method="raster")

  keyValue <- readline("Press any key to show extra-high RGB-value in an image.")
  display(rgbImage(red=x1_ct_r, green= x1_ct_g, blue=x1_ct_b), method="raster")

  # Verify each converted values on this following site.  
  # http://davengrace.com/cgi-bin/cspace.pl  
  x1_XYZ  <- transColorSpace(x1, transMode = "CIEXYZ")
  x1_Lab  <- transColorSpace(x1_XYZ, transMode = "CIELAB")
  xlsx_name <- paste("AnalyzedImage04-", timeTag, ".xlsx", sep="")
  nameFile  <- paste("./srcImage/", xlsx_name, sep="")
  dataWB   <- loadWorkbook(nameFile, create = TRUE)
    saveXlsx(dataWB, "RGB-R", x1[,,1])
    saveXlsx(dataWB, "RGB-G", x1[,,2])
    saveXlsx(dataWB, "RGB-B", x1[,,3])
    saveXlsx(dataWB, "CIEXYZ-X", x1_XYZ[,,1])
    saveXlsx(dataWB, "CIEXYZ-Y", x1_XYZ[,,2])
    saveXlsx(dataWB, "CIEXYZ-Z", x1_XYZ[,,3])
    saveXlsx(dataWB, "CIELab-L", x1_Lab[,,1])
    saveXlsx(dataWB, "CIELab-a", x1_Lab[,,2])
    saveXlsx(dataWB, "CIELab-b", x1_Lab[,,3])
  saveWorkbook(dataWB)


  temp_mask <- thresh(x1, 10, 10, 0.03)
  temp_mask <- opening(temp_mask, makeBrush(3, shape="disc"))
  temp_mask <- fillHull(bwlabel(temp_mask))

  x1_mask_r <- opening(x1[,,1]>mean(x1[,,1]) + sd(x1[,,1]), makeBrush(3, shape="disc"))
  x1_mask_g <- opening(x1[,,2]>mean(x1[,,2]) + sd(x1[,,2]), makeBrush(3, shape="disc"))
  x1_mask_b <- opening(x1[,,3]>mean(x1[,,3]) + sd(x1[,,3]), makeBrush(3, shape="disc"))

  x1_mask   <- array(0, c(length(x1[,1,1]), length(x1[1,,1]),3))
  x1_mask[,,1] <- x1_mask_r
  x1_mask[,,2] <- x1_mask_g
  x1_mask[,,3] <- x1_mask_b
  x1_mask   <- as.Image(x1_mask)

  lst_mask  <- propagate(x1, temp_mask, x1_mask)
  lst_mask_bw <- channel(lst_mask, 'gray')
  temp_mask_bw <- channel(temp_mask, 'gray')
  #rslt_x1   <- fillHull(bwlabel(lst_mask_bw))
  #temp_mask_bw <- fillHull(bwlabel(temp_mask_bw))
  
  rslt_x1   <- paintObjects(lst_mask_bw, x1, opac=c(1,1), col=c('#ff0000', NA))
  rslt_x1   <- paintObjects(temp_mask_bw, rslt_x1, opac=c(1,1), col=c('#000000', NA))

  keyValue <- readline("Press any key to show an melanin and erythema diaginosys result image.")
  display(rslt_x1, method="raster")
  writeImage(rslt_x1, paste("./srcImage/AnalyzedImage10-", timeTag, ".png", sep=""), quality=100)


x1_EI <- 10*(log10(1/x1[,,2])-1.44*log10(1/x1[,,1]))
x1_MI <- log10(1/x1[,,1])
x1_EI <- as.Image(x1_EI)
x1_MI <- as.Image(x1_MI)
#keyValue <- readline("Press any key to proceed the next step")
#x1_EIMI <- EBImage::combine(x1_EI, x1_MI)
#display(x1_EIMI, all=TRUE, method="raster")

pal.1=colorRampPalette(c("blue","green", "yellow", "red"), space="rgb")
breaks <- seq(min(x1_EI), max(x1_EI),length.out=100)
par(mar=c(3,3,3,3))
x1_EI  <- x1_EI[,ncol(x1_EI):1]
keyValue <- readline("Press any key to show erythema diagnosys image by Dermavision algorithm")
x1_EI_DV <- graphics::image(seq(dim(x1_EI)[1]), seq(dim(x1_EI)[2]), x1_EI, 
                            col=pal.1(length(breaks)-1), breaks=breaks, xaxt="n", yaxt="n", ylab="", xlab="")
#Add additional graphics
highest <- which.max(x1_EI)
points(highest %% dim(x1_EI)[1], highest %/% dim(x1_EI)[1], 
       pch=2, lwd=2, cex=2,col="blue")
#   #Add scale
#   par(mar=c(15,5,5,5))
#   image.scale(x1_EI_DV, col=pal.1(length(breaks)-1), breaks=breaks, horiz=TRUE)
pal.2=colorRampPalette(c("blue","green","yellow", "red"), space="rgb")
breaks <- seq(min(x1_MI), max(x1_MI),length.out=100)
par(mar=c(3,3,3,3))
x1_MI  <- x1_MI[,ncol(x1_MI):1]
keyValue <- readline("Press any key to show melanin diagnosys image by Dermavision algorithm")
x1_MI_DV <- graphics::image(seq(dim(x1_MI)[1]), seq(dim(x1_MI)[2]), x1_MI, 
                            col=pal.2(length(breaks)-1), breaks=breaks, xaxt="n", yaxt="n", ylab="", xlab="")
#Add additional graphics
highest <- which.max(x1_MI)
points(highest %% dim(x1_MI)[1], highest %/% dim(x1_MI)[1], 
       pch=2, lwd=2, cex=2,col="blue")


x1_L   <- normalize(x1_Lab[,,1])
pal.3=colorRampPalette(c("black", "white"), space="rgb")
breaks <- seq(min(x1_L), max(x1_L),length.out=100)
par(mar=c(3,3,3,3))
x1_L  <- x1_L[,ncol(x1_L):1]
keyValue <- readline("Press any key to show a result image of L* value of CIE Lab")
x1_L_DV <- graphics::image(seq(dim(x1_L)[1]), seq(dim(x1_L)[2]), x1_L, 
                           col=pal.3(length(breaks)-1), breaks=breaks, xaxt="n", yaxt="n", ylab="", xlab="")
#Add additional graphics
minimal <- which.min(x1_L)
points(minimal %% dim(x1_L)[1], minimal %/% dim(x1_L)[1], 
       pch=2, lwd=2, cex=2,col="blue")

x1_a   <- normalize(x1_Lab[,,2])
pal.4=colorRampPalette(c("green", "red"), space="rgb")
breaks <- seq(min(x1_a), max(x1_a),length.out=100)
par(mar=c(3,3,3,3))
x1_a  <- x1_a[,ncol(x1_a):1]
keyValue <- readline("Press any key to show a result image of a* value of CIE Lab")
x1_a_DV <- graphics::image(seq(dim(x1_a)[1]), seq(dim(x1_a)[2]), x1_a, 
                           col=pal.4(length(breaks)-1), breaks=breaks, xaxt="n", yaxt="n", ylab="", xlab="")
#Add additional graphics
highest <- which.max(x1_a)
points(highest %% dim(x1_a)[1], highest %/% dim(x1_a)[1], 
       pch=2, lwd=2, cex=2,col="blue")

x1_b   <- normalize(x1_Lab[,,3])
pal.5=colorRampPalette(c("blue", "yellow"), space="rgb")
breaks <- seq(min(x1_b), max(x1_b),length.out=100)
par(mar=c(3,3,3,3))
x1_b  <- x1_b[,ncol(x1_b):1]
keyValue <- readline("Press any key to show a result image of b* value of CIE Lab")
x1_b_DV <- graphics::image(seq(dim(x1_b)[1]), seq(dim(x1_b)[2]), x1_b, 
                           col=pal.5(length(breaks)-1), breaks=breaks, xaxt="n", yaxt="n", ylab="", xlab="")
#Add additional graphics
minimal <- which.min(x1_b)
points(minimal %% dim(x1_b)[1], minimal %/% dim(x1_b)[1], 
       pch=2, lwd=2, cex=2,col="red")

}

