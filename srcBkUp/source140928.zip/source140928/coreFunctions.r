# ==========================================================================
# This program is developed to diagnosis skin status of human face.
#                                       Created by Ph.D./Prof. Jaeho H. BAE
#                           Dept. of Industrial Management, Osan University
#                                                                Sep., 2014.
#                                                     knowhow.bae@gmail.com
# ==========================================================================

lib.call <- function() {
  require("XLConnect")
  require("EBImage")
  require("colorscience")
  source("usedFunctions.r")
}