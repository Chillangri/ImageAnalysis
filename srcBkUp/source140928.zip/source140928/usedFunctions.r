# Color conversion rules from following site
# http://www.cs.rit.edu/~ncs/color/t_convert.html#XYZ%20to%20CIE%20L*a*b*%20(CIELAB)%20&%20CIELAB%20to%20XYZ

myRGB2XYZ <- function(matRGB) {
  k <- c(0.412453, 0.212671, 0.019334, 0.357580, 0.715160, 0.119193, 0.180423, 0.072169, 0.950227)
  k <- matrix(k, ncol=3)  
  
  valXYZ <- k %*% t(matRGB)
  return(t(valXYZ))  
}

myXYZ2RGB <- function(matXYZ) {
  k <- c(3.240479, -0.969256, 0.055648, -1.537150, 1.875992, -0.204043, -0.498535, 0.041556, 1.057311)
  k <- matrix(k, ncol=3)
  
  valRGB <- k %*% t(matXYZ)
  return(t(valRGB))
}


myXYZ2Lab <- function(matXYZ) {
  if (is.null(nrow(matXYZ))) {
    matXYZ <- matrix(matXYZ, nrow=1)
    valLab <- matrix(0, nrow = nrow(matXYZ), ncol = ncol(matXYZ))    
  } else {
    valLab <- matrix(0, nrow = nrow(matXYZ), ncol = ncol(matXYZ))
  }
  refX <- 0.950456
  refY <- 1.000000
  refZ <- 1.088754
  refVal <- c(refX, refY, refZ)
  funcX <- matrix(0, nrow=nrow(matXYZ), ncol=1)
  funcY <- matrix(0, nrow=nrow(matXYZ), ncol=1)
  funcZ <- matrix(0, nrow=nrow(matXYZ), ncol=1)

  # 첨자 내부의 값들이 제대로 반영되도록... which 함수 사용 
#   if(matXYZ[,1]/refX > (6/29)^3) {
#     funcX <- (matXYZ[,1]/refX)^(1/3)
#   } else {
#     funcX <- (1/3) * (29/6)^2 * (matXYZ[,1]/refX) + (4/29)
#   }
#   if(matXYZ[,2]/refY > (6/29)^3) {
#     funcY <- (matXYZ[,2]/refY)^(1/3)    
#   } else {
#     funcY <- (1/3) * (29/6)^2 * (matXYZ[,2]/refY) + (4/29)
#   }
#   if(matXYZ[,3]/refZ > (6/29)^3) {
#     funcZ <- (matXYZ[,3]/refZ)^(1/3)
#   } else {
#     funcZ <- (1/3) * (29/6)^2 * (matXYZ[,3]/refZ) + (4/29)
#   }

  for (i in 1:nrow(matXYZ)) {
    if (matXYZ[i,1]/refX > (6/29)^3) {
      funcX[i] <- (matXYZ[i,1]/refX)^(1/3)
    } else {
      funcX[i] <- (1/3) * (29/6)^2 * (matXYZ[i,1]/refX) + (4/29)
    }
    
    if (matXYZ[i,2]/refY > (6/29)^3) {
      funcY[i] <- (matXYZ[i,2]/refY)^(1/3)
    } else {
      funcY[i] <- (1/3) * (29/6)^2 * (matXYZ[i,2]/refY) + (4/29)
    }

    if (matXYZ[i,3]/refZ > (6/29)^3) {
      funcZ[i] <- (matXYZ[i,3]/refZ)^(1/3)
    } else {
      funcZ[i] <- (1/3) * (29/6)^2 * (matXYZ[i,3]/refZ) + (4/29)
    }
  }

  valLab[,1] <- 116 * funcY -16
  valLab[,2] <- 500 * (funcX - funcY)
  valLab[,3] <- 200 * (funcY - funcZ)
  return(valLab)
}

myLab2XYZ <- function(matLab) {
  if (is.null(nrow(matLab))) {
    matLab <- matrix(matLab, nrow=1)
    valXYZ <- matrix(0, nrow = nrow(matLab), ncol = ncol(matLab))    
  } else {
    valXYZ <- matrix(0, nrow = nrow(matLab), ncol = ncol(matLab))
  }
  refX <- 0.950456  
  refY <- 1.000000
  refZ <- 1.088754
  refVal <- c(refX, refY, refZ)
  revX <- matrix(0, nrow=nrow(matLab), ncol=1)
  revY <- matrix(0, nrow=nrow(matLab), ncol=1)
  revZ <- matrix(0, nrow=nrow(matLab), ncol=1)
  
  
  # 다음의 링크에 따라 공식 확인
  # http://en.wikipedia.org/wiki/Lab_color_space
  for (i in 1:nrow(matLab)) {
    t_x <- (1/116) * (matLab[i,1]+16) + (1/500) * matLab[i,2]
    t_y <- (1/116) * (matLab[i,1]+16)
    t_z <- (1/116) * (matLab[i,1]+16) - (1/200) * matLab[i,3]

    if (t_x > (6/29)) {
      revX[i] <- t_x^3
    } else {
      revX[i] <- 3 * (6/29)^2 * (t_x - (4/29))
    }
    
    if (t_y > (6/29)) {
      revY[i] <- t_y^3
    } else {
      revY[i] <- 3 * (6/29)^2 * (t_y - (4/29))
    }
    
    if (t_z > (6/29)) {
      revZ[i] <- t_z^3
    } else {
      revZ[i] <- 3 * (6/29)^2 * (t_z - (4/29))
    }
  }
  
  valXYZ[,1] <- refX * revX
  valXYZ[,2] <- refY * revY
  valXYZ[,3] <- refZ * revZ
  return(valXYZ)
}

axis.normalize <- function(axis.current,..., minVal=NULL, maxVal=NULL, minTar=0, maxTar=1) {
  if (is.null(nrow(axis.current))) {
    axis.current <- matrix(axis.current)
  } else {
    axis.current <- matrix(axis.current, ncol=ncol(axis.current), nrow=nrow(axis.current))
  }
  
  if (is.null(minVal)) {
    min.value  <- min(axis.current)  
  } else {min.value <- minVal}
  
  if (is.null(maxVal)) {
    max.value  <- max(axis.current)
  } else {max.value <- maxVal}

  norm.value <- normalize(axis.current, ft=c(minTar, maxTar), inputRange=c(min.value, max.value))
  return.val <- list(min = min.value, max = max.value, data = norm.value)
  return(return.val)
}

axis.denormalize <- function(data, min, max) {
  return.val <- data * (max-min) + min
  return(return.val)
}

image.scale <- function(z, zlim, col = heat.colors(12),
                        breaks, horiz=TRUE, ylim=NULL, xlim=NULL, ...){
  if(!missing(breaks)){
    if(length(breaks) != (length(col)+1)){stop("must have one more break than colour")}
  }
  if(missing(breaks) & !missing(zlim)){
    breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1)) 
  }
  if(missing(breaks) & missing(zlim)){
    zlim <- range(z, na.rm=TRUE)
    zlim[2] <- zlim[2]+c(zlim[2]-zlim[1])*(1E-3)#adds a bit to the range in both directions
    zlim[1] <- zlim[1]-c(zlim[2]-zlim[1])*(1E-3)
    breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1))
  }
  poly <- vector(mode="list", length(col))
  for(i in seq(poly)){
    poly[[i]] <- c(breaks[i], breaks[i+1], breaks[i+1], breaks[i])
  }
  xaxt <- ifelse(horiz, "s", "n")
  yaxt <- ifelse(horiz, "n", "s")
  if(horiz){YLIM<-c(0,1); XLIM<-range(breaks)}
  if(!horiz){YLIM<-range(breaks); XLIM<-c(0,1)}
  if(missing(xlim)) xlim=XLIM
  if(missing(ylim)) ylim=YLIM
  plot(1,1,t="n",ylim=ylim, xlim=xlim, xaxt=xaxt, yaxt=yaxt, xaxs="i", yaxs="i", ...)  
  for(i in seq(poly)){
    if(horiz){
      polygon(poly[[i]], c(0,0,1,1), col=col[i], border=NA)
    }
    if(!horiz){
      polygon(c(0,0,1,1), poly[[i]], col=col[i], border=NA)
    }
  }
}


saveXlsx <- function(dataWB, nameSheet, setData) {
  options(java.parameters = "-Xmx4096m")
  
  dataWS   <- createSheet(dataWB, name = nameSheet)
  writeWorksheet(dataWB, setData, sheet = nameSheet)
#  saveWorkbook(dataWB)
  
  xlcFreeMemory()
  return(1)
}


transColor2RGB  <- function(valColor, transMode){
    dimOfvalue <- dim(valColor)
  numPages   <- dimOfvalue[3]
  numCols    <- length(valColor[1,,1])
  numRows    <- length(valColor[,1,1])
  rtnColor   <- array(0, c(numRows, numCols, numPages))
  
  if (transMode == "CIEXYZ") {
    for (c in 1:numCols) {
      rtnColor[, c, ]  <- myLab2XYZ(cbind(valColor[, c, 1], valColor[, c, 2], valColor[, c, 3]))
    }
  } else if (transMode == "RGB") {
    for (c in 1:numCols) {
      rtnColor[, c, ]  <- myXYZ2RGB(cbind(valColor[, c, 1], valColor[, c, 2], valColor[, c, 3])/100)
    }
  } else {
    rtnColor <- valColor
  }
  return(rtnColor)
}


transColorSpace <- function(valRGB, transMode) {
      dimOfvalue <- dim(valRGB)
  numPages   <- dimOfvalue[3]
  numCols    <- length(valRGB[1,,1])
  numRows    <- length(valRGB[,1,1])
  rtnColor   <- array(0, dim=c(numRows, numCols, numPages))
  
  if (transMode == "CIEXYZ") {
    for (c in 1:numCols) {
        rtnColor[, c, ]  <- myRGB2XYZ(cbind(valRGB[,c,1], valRGB[,c,2], valRGB[,c,3]))
    }
  } else if (transMode == "CIELAB") {
    for (c in 1:numCols) {
        rtnColor[, c, ]  <- myXYZ2Lab(cbind(valRGB[,c,1], valRGB[,c,2], valRGB[,c,3]))
    }    
  } else {
    rtnColor <- valRGB
  }
  return(rtnColor)
}

getFileName <- function(dataFile) {
  currentWD <- paste(getwd(), "/srcImage", sep="")
  cat("Your DATA files must be at ", currentWD, "\n", sep="")
  ANS <- readline("Is it right? (Y/y or N/n): ")
  
  if ((substr(ANS, 1, 1)=="n") || (substr(ANS, 1, 1)=="N")) {
    return()
  } else {
    imgFileName <- readline("What is the Image file Name? ")
    imgFileName <- paste(currentWD, "/", imgFileName, sep="")
    coordFileName <- readline("What is the Coordination file Name? ")
    coordFileName <- paste(currentWD, "/", coordFileName, sep="")
    
    dataFile$imgFile <- imgFileName
    dataFile$locFile <- coordFileName
    return(dataFile)
  }
}
